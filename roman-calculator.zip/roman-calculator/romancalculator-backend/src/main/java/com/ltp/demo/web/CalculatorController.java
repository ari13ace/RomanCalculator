package com.ltp.demo.web;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/calculate")
class CalculatorController {
    @GetMapping
    public String calculate(@RequestParam int num1, @RequestParam int num2, @RequestParam String operation) {
        int result;
        switch (operation) {
            case "add":
                result = num1 + num2;
                break;
            case "subtract":
                result = num1 - num2;
                break;
            case "multiply":
                result = num1 * num2;
                break;
            case "divide":
                if (num2 == 0) return "Cannot divide by zero"; // check for division by 0
                result = num1 / num2;
                break;
            default:
                return "Invalid operation"; // check for invalid inputs 
        }
        return toRoman(result);
    }

    /** toRoman:  method for turning an integer number into a roman numeral
     *            if the input is within range of 1-3999; else will return a
     *            error message string
     * @param number integer to be converted to roman numeral string
     * @return string of the roman numeral
    */
    private String toRoman(int number) {
        if (number < 1 || number > 3999) {
            return "Out of range";
        }
        //use parallel arrays holding Roman numeral symbols and their corresponding values
        String[] romanNumerals = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        // build the roman numeral using the mutable string class of Stringbuilder
        StringBuilder roman = new StringBuilder(); 

        // iterate through values array to find corresponding Roman numeral
        for (int i = 0; i < values.length; i++) {
            while (number >= values[i]) {
                number -= values[i];
                // append the corresponding Roman numeral to the result
                roman.append(romanNumerals[i]); 
            }
        }
        // convert StringBuilder object to String and return the final Roman numeral
        return roman.toString(); 
    }
}
