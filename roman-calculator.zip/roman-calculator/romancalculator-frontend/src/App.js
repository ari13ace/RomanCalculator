import { useState } from "react";
import axios from "axios";

function App() {
  const [num1, setNum1] = useState("");
  const [num2, setNum2] = useState("");
  const [operation, setOperation] = useState("add");
  const [result, setResult] = useState(null);

  const calculate = async () => {
    try {
      const response = await axios.get("http://localhost:8080/calculate", {
        params: { num1, num2, operation },
      });
      setResult(response.data);
    } catch (error) {
      setResult("Error: " + error.message);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto text-center border rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold">Roman Numeral Calculator</h1>
      <input 
        type="number" 
        value={num1} 
        onChange={(e) => setNum1(e.target.value)} 
        placeholder="Enter first number" 
        className="block w-full p-2 border rounded mt-2"
      />
      <input 
        type="number" 
        value={num2} 
        onChange={(e) => setNum2(e.target.value)} 
        placeholder="Enter second number" 
        className="block w-full p-2 border rounded mt-2"
      />
      <select 
        value={operation} 
        onChange={(e) => setOperation(e.target.value)} 
        className="block w-full p-2 border rounded mt-2"
      >
        <option value="add">Add</option>
        <option value="subtract">Subtract</option>
        <option value="multiply">Multiply</option>
        <option value="divide">Divide</option>
      </select>
      <button 
        onClick={calculate} 
        className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Calculate
      </button>
      {result && (
        <p className="mt-4 text-lg font-semibold">Result: {result}</p>
      )}
    </div>
  );
}

export default App;
