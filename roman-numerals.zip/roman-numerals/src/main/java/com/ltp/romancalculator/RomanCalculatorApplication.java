package com.ltp.romancalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RomanCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RomanCalculatorApplication.class, args);
	}

}
