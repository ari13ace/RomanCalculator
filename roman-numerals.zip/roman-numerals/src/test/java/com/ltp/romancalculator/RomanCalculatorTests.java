package com.ltp.romancalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RomanCalculatorTests {

	@Test
	void contextLoads() {
	}

}
